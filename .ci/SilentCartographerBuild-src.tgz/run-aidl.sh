cd /sdcard/SilentCartographerBuild
bash ./gradlew --no-daemon --max-workers=2 :app:compileDebugAidl --stacktrace --console=plain > /sdcard/SilentCartographerBuild/aidl.log 2>&1
printf '%s\n' "$?" > /sdcard/SilentCartographerBuild/aidl.exit
