cd /sdcard/SilentCartographerBuild
rm -f /sdcard/SilentCartographerBuild/build.exit
bash ./gradlew --no-daemon --max-workers=2 :app:assembleDebug --console=plain > /sdcard/SilentCartographerBuild/build.log 2>&1
printf '%s\n' "$?" > /sdcard/SilentCartographerBuild/build.exit
