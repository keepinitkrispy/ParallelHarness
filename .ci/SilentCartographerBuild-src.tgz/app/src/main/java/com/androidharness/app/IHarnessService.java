/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: aidl -I app/src/main/aidl app/src/main/aidl/com/androidharness/app/IHarnessService.aidl app/src/main/java/com/androidharness/app/IHarnessService.java
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.androidharness.app;
/**
 * Runs inside the Shizuku server process with ADB-shell (or root) privileges.
 * The Shizuku server instantiates {@link com.androidharness.app.data.env.HarnessUserService}
 * reflectively, so the app needs only the IHarnessService class + a bind via
 * Shizuku.bindUserService — no <service> entry in the manifest.
 */
public interface IHarnessService extends android.os.IInterface
{
  /** Default implementation for IHarnessService. */
  public static class Default implements com.androidharness.app.IHarnessService
  {
    // Reserved method + transaction id: the Shizuku server calls this when it
    // wants to stop running this user service.
    @Override public void destroy() throws android.os.RemoteException
    {
    }
    // Tells the in-server service to exit its process (it will be restarted
    // on the next bind).
    @Override public void exit() throws android.os.RemoteException
    {
    }
    /**
     * Executes a command as the Shizuku server process uid (shell 2000, or
     * root when started via Sui/root).
     * 
     * @param cmd argv, e.g. ["sh", "-c", "ls -l /sdcard"]
     * @param env "KEY=VALUE" entries, may be null
     * @param dir working directory, may be null
     * @param maxBytes cap on the combined stdout+stderr returned (bounded well
     *                 below the binder transaction limit)
     * @param timeoutMs hard kill timeout in milliseconds
     * @return "exit=N\ntimeout=0|1\n<combined output>" (N=-1 when launch failed)
     */
    @Override public java.lang.String exec(java.lang.String[] cmd, java.lang.String[] env, java.lang.String dir, int maxBytes, int timeoutMs) throws android.os.RemoteException
    {
      return null;
    }
    /**
     * Starts a command as a detached child of the Shizuku server process,
     * output appended to logPath. Because it lives in the server process it
     * survives the app being killed. Returns the pid, or -1 on failure.
     */
    @Override public int spawnDetached(java.lang.String[] cmd, java.lang.String[] env, java.lang.String dir, java.lang.String logPath) throws android.os.RemoteException
    {
      return 0;
    }
    /** kill(pid, 0)-style liveness probe. */
    @Override public boolean isProcessAlive(int pid) throws android.os.RemoteException
    {
      return false;
    }
    /** SIGKILL a process by pid. */
    @Override public boolean killProcess(int pid) throws android.os.RemoteException
    {
      return false;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.androidharness.app.IHarnessService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.androidharness.app.IHarnessService interface,
     * generating a proxy if needed.
     */
    public static com.androidharness.app.IHarnessService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.androidharness.app.IHarnessService))) {
        return ((com.androidharness.app.IHarnessService)iin);
      }
      return new com.androidharness.app.IHarnessService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_destroy:
        {
          this.destroy();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_exit:
        {
          this.exit();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_exec:
        {
          java.lang.String[] _arg0;
          _arg0 = data.createStringArray();
          java.lang.String[] _arg1;
          _arg1 = data.createStringArray();
          java.lang.String _arg2;
          _arg2 = data.readString();
          int _arg3;
          _arg3 = data.readInt();
          int _arg4;
          _arg4 = data.readInt();
          java.lang.String _result = this.exec(_arg0, _arg1, _arg2, _arg3, _arg4);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_spawnDetached:
        {
          java.lang.String[] _arg0;
          _arg0 = data.createStringArray();
          java.lang.String[] _arg1;
          _arg1 = data.createStringArray();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _arg3;
          _arg3 = data.readString();
          int _result = this.spawnDetached(_arg0, _arg1, _arg2, _arg3);
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_isProcessAlive:
        {
          int _arg0;
          _arg0 = data.readInt();
          boolean _result = this.isProcessAlive(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_killProcess:
        {
          int _arg0;
          _arg0 = data.readInt();
          boolean _result = this.killProcess(_arg0);
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.androidharness.app.IHarnessService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      // Reserved method + transaction id: the Shizuku server calls this when it
      // wants to stop running this user service.
      @Override public void destroy() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_destroy, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      // Tells the in-server service to exit its process (it will be restarted
      // on the next bind).
      @Override public void exit() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_exit, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      /**
       * Executes a command as the Shizuku server process uid (shell 2000, or
       * root when started via Sui/root).
       * 
       * @param cmd argv, e.g. ["sh", "-c", "ls -l /sdcard"]
       * @param env "KEY=VALUE" entries, may be null
       * @param dir working directory, may be null
       * @param maxBytes cap on the combined stdout+stderr returned (bounded well
       *                 below the binder transaction limit)
       * @param timeoutMs hard kill timeout in milliseconds
       * @return "exit=N\ntimeout=0|1\n<combined output>" (N=-1 when launch failed)
       */
      @Override public java.lang.String exec(java.lang.String[] cmd, java.lang.String[] env, java.lang.String dir, int maxBytes, int timeoutMs) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringArray(cmd);
          _data.writeStringArray(env);
          _data.writeString(dir);
          _data.writeInt(maxBytes);
          _data.writeInt(timeoutMs);
          boolean _status = mRemote.transact(Stub.TRANSACTION_exec, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /**
       * Starts a command as a detached child of the Shizuku server process,
       * output appended to logPath. Because it lives in the server process it
       * survives the app being killed. Returns the pid, or -1 on failure.
       */
      @Override public int spawnDetached(java.lang.String[] cmd, java.lang.String[] env, java.lang.String dir, java.lang.String logPath) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringArray(cmd);
          _data.writeStringArray(env);
          _data.writeString(dir);
          _data.writeString(logPath);
          boolean _status = mRemote.transact(Stub.TRANSACTION_spawnDetached, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** kill(pid, 0)-style liveness probe. */
      @Override public boolean isProcessAlive(int pid) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(pid);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isProcessAlive, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      /** SIGKILL a process by pid. */
      @Override public boolean killProcess(int pid) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(pid);
          boolean _status = mRemote.transact(Stub.TRANSACTION_killProcess, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    static final int TRANSACTION_destroy = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16777114);
    static final int TRANSACTION_exit = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_exec = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_spawnDetached = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_isProcessAlive = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_killProcess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.androidharness.app.IHarnessService";
  // Reserved method + transaction id: the Shizuku server calls this when it
  // wants to stop running this user service.
  public void destroy() throws android.os.RemoteException;
  // Tells the in-server service to exit its process (it will be restarted
  // on the next bind).
  public void exit() throws android.os.RemoteException;
  /**
   * Executes a command as the Shizuku server process uid (shell 2000, or
   * root when started via Sui/root).
   * 
   * @param cmd argv, e.g. ["sh", "-c", "ls -l /sdcard"]
   * @param env "KEY=VALUE" entries, may be null
   * @param dir working directory, may be null
   * @param maxBytes cap on the combined stdout+stderr returned (bounded well
   *                 below the binder transaction limit)
   * @param timeoutMs hard kill timeout in milliseconds
   * @return "exit=N\ntimeout=0|1\n<combined output>" (N=-1 when launch failed)
   */
  public java.lang.String exec(java.lang.String[] cmd, java.lang.String[] env, java.lang.String dir, int maxBytes, int timeoutMs) throws android.os.RemoteException;
  /**
   * Starts a command as a detached child of the Shizuku server process,
   * output appended to logPath. Because it lives in the server process it
   * survives the app being killed. Returns the pid, or -1 on failure.
   */
  public int spawnDetached(java.lang.String[] cmd, java.lang.String[] env, java.lang.String dir, java.lang.String logPath) throws android.os.RemoteException;
  /** kill(pid, 0)-style liveness probe. */
  public boolean isProcessAlive(int pid) throws android.os.RemoteException;
  /** SIGKILL a process by pid. */
  public boolean killProcess(int pid) throws android.os.RemoteException;
}
