package com.androidharness.app.ui.cartographer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private data class RoomEvent(
    val id: String,
    val speaker: String,
    val text: String,
)

private const val BRIDGE = "http://127.0.0.1:49174"
@Composable
fun SilentCartographerScreen(onOpenDrawer: () -> Unit) {
    val client = remember {
        OkHttpClient.Builder()
            .connectTimeout(2, TimeUnit.SECONDS)
            .readTimeout(150, TimeUnit.SECONDS)
            .build()
    }
    val scope = rememberCoroutineScope()
    var events by remember { mutableStateOf<List<RoomEvent>>(emptyList()) }
    var draft by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    suspend fun refresh() {
        val result = withContext(Dispatchers.IO) {
            runCatching {
                client.newCall(Request.Builder().url(BRIDGE + "/events").get().build())
                    .execute().use { response ->
                        check(response.isSuccessful) { "HTTP " + response.code }
                        val root = JSONObject(response.body?.string().orEmpty())
                        val array = root.getJSONArray("events")
                        buildList {
                            for (i in 0 until array.length()) {
                                val e = array.getJSONObject(i)
                                if (e.optString("kind", "message") == "message") {
                                    add(
                                        RoomEvent(
                                            id = e.optString("id", i.toString()),
                                            speaker = e.optString("speaker", "Unknown"),
                                            text = e.optString("text"),
                                        )
                                    )
                                }
                            }
                        }
                    }
            }
        }
        result.onSuccess {
            events = it
            error = null
        }.onFailure {
            error = "Local bridge unavailable: " + (it.message ?: "unknown error")
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            refresh()
            delay(1400)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onOpenDrawer) {
                Icon(Icons.Filled.Menu, contentDescription = "Open navigation")
            }
            Column(Modifier.weight(1f)) {
                Text(
                    "Silent Cartographer",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    "Ryan  •  ChatGPT  •  Claude",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (sending) CircularProgressIndicator(Modifier.padding(end = 12.dp))
        }

        error?.let { message ->
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text(
                    message,
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(events, key = { it.id }) { event ->
                val mine = event.speaker == "Ryan"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
                ) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = when (event.speaker) {
                            "Ryan" -> MaterialTheme.colorScheme.primaryContainer
                            "ChatGPT" -> MaterialTheme.colorScheme.secondaryContainer
                            "Claude" -> MaterialTheme.colorScheme.tertiaryContainer
                            else -> MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                        modifier = Modifier.widthIn(max = 330.dp),
                    ) {
                        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Text(
                                event.speaker,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(event.text, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message the room…") },
                maxLines = 5,
            )
            Button(
                enabled = draft.isNotBlank() && !sending,
                onClick = {
                    val text = draft.trim()
                    draft = ""
                    sending = true
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            runCatching {
                                val payload = JSONObject().put("text", text).toString()
                                val body = payload.toRequestBody("application/json".toMediaType())
                                client.newCall(
                                    Request.Builder().url(BRIDGE + "/user-send").post(body).build()
                                ).execute().use { response ->
                                    check(response.isSuccessful) { "HTTP " + response.code }
                                }
                            }
                        }
                        result.onFailure {
                            error = "Send failed: " + (it.message ?: "unknown error")
                        }
                        sending = false
                        refresh()
                    }
                },
            ) { Text("Send") }
        }
    }
}
